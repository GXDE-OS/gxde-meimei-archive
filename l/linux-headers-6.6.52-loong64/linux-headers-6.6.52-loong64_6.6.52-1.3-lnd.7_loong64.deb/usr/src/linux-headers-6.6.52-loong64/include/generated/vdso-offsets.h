#define vdso_offset_sigreturn	0x0910
