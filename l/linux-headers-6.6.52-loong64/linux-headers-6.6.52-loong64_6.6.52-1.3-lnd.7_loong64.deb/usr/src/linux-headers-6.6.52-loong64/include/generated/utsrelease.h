#define UTS_RELEASE "6.6.52-loong64"
