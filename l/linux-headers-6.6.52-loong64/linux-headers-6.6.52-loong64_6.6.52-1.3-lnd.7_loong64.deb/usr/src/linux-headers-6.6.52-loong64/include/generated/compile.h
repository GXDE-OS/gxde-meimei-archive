#define UTS_MACHINE		"loongarch64"
#define LINUX_COMPILE_BY	"debian-kernel"
#define LINUX_COMPILE_HOST	"lists.debian.org"
#define LINUX_COMPILER		"loongarch64-linux-gnu-gcc-14 (Debian 14.2.0-4) 14.2.0, GNU ld (GNU Binutils for Debian) 2.43.1"
